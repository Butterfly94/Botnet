TOKEN = "7649281985:AAGifutjShUTa2fpV4EGjfNyIewYPAosEZ0" # Токен бота
CRYPTO = "291638:AABqfKxYCtsxEPuE0tYsSZhGxs5Lkk3SeWB" # Токен CryptoBot
ADMINS = [6930566625, ] # ID Админов

# Bot Options
bot_name = "Dr. Jekyll"
bot_logs = "-1002227089747"
bot_channel_link = "https://t.me/dr_jekylltg"
bot_admin = "@Mr_Hayde"
bot_documentation = ""
bot_works = ""
bot_reviews = ""

# Price
subscribe_1_day = 1.99
subscribe_7_days = 3.99
subscribe_14_days = 5.99
subscribe_30_days = 9.99
subscribe_365_days = 17.99
subscribe_infinity_days = 35.99